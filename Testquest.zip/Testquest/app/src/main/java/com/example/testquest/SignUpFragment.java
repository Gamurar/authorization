package com.example.testquest;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

public class SignUpFragment extends Fragment {

    EditText mNickname;
    EditText mEmail;
    EditText mPassword;

    public SignUpFragment() {

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_sign_up, container, false);
        mNickname = rootView.findViewById(R.id.nickname_et);
        mEmail = rootView.findViewById(R.id.email_et);
        mPassword = rootView.findViewById(R.id.password_et);
        return rootView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mNickname.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    String nickname = mNickname.getText().toString();
                    if (checkNickname(nickname) == null) {
                        mNickname.setCompoundDrawablesWithIntrinsicBounds(0,0,
                                R.drawable.ic_check, 0);
                    } else {
                        mNickname.setCompoundDrawablesWithIntrinsicBounds(0,0,
                                R.drawable.ic_wrong, 0);
                    }
                }
            }
        });

        mEmail.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    String email = mEmail.getText().toString();
                    if (isValidEmail(email)) {
                        mEmail.setCompoundDrawablesWithIntrinsicBounds(0,0,
                                R.drawable.ic_check, 0);
                    } else {
                        mEmail.setCompoundDrawablesWithIntrinsicBounds(0,0,
                                R.drawable.ic_wrong, 0);
                    }
                }
            }
        });
    }

    private String checkNickname(String nickname) {
        if (nickname.isEmpty()) {
            return  "The nickname field can not be empty.";
        } else if (nickname.length() < 3) {
            return "Too short nickname.";
        }
        else return null;
    }

    private boolean isValidEmail(CharSequence target) {
        return (!TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches());
    }
}
